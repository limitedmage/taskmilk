Author: Juliana Pe�a
Website: http://julianapena.com

Credits:
- Remember the Milk http://rememberthemilk.com
for such an awesome service
- Tyler Sticka http://tylersticka.com/2009/02/remember-the-milk-favicon-redesigned/
for the awesome high rez icon

This extension is open source under the GPLv2.
http://creativecommons.org/licenses/GPL/2.0/